#ifndef NICOLAS2_H
#define NICOLAS2_H

void nicolas2(char* fic_src, char* fic_dest);


#endif /*NICOLAS2_H */