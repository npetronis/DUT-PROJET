#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include<graph.h>
 

 /*fonction pour lire ligne par ligne dans un fichier source, convertir les lignes et les écrires dans
le fichier destination */

char delim[] = " "; 
char inst[20] = "ADD #57 -1";
char inst2[20] = "MOV #0 @-2";
	long long int le_code = 0;
   	long long i = 0;
	long long mema = 0;
	long long memb = 0;
	long long vala = 0;
	long long valb = 0;
    	char *mnemo;
	char *arg1;
	char *arg2;
	char buff[20];
	char buffsrc[20];
	char buffdest[20];		
	char buff2[20];

void argument(char *arg, long long *mem, long long *val);
void nicolas(char* fic_src, char* fic_dest);

int main(int argc, char *argv[]) {
	int k= 10;
	int kk;
	
	InitialiserGraphique();
	CreerFenetre(0,0,900,900);
	DessinerRectangle(0,0,900,400);
	DessinerRectangle(0,401,900,400);
	DessinerSegment(700,1,700,399);
	DessinerSegment(700,401,700,899);
	EcrireTexte(705, 203,"premier programme",0);
	EcrireTexte(705, 604,"deuxieme programme",0);	
        while (1){
        if(SourisCliquee()){
        if ( _X>=700 && _X<=900 && _Y>=1 && _Y<=399)
        {
        nicolas("redcode.ass","redcode.mars");

    //ouverture des flux de fichiers
   	FILE *source = fopen("redcode2.ass","r");
	FILE *destination = fopen("redcode2.mars","w");
	while(!feof(source) && !feof(destination)){
	fgets( buffsrc,20,source);
	printf("%s",buffsrc);
	fgets( buffdest,20,destination);
	EcrireTexte(5, 800 ,"testes",0);
	//ChoisirEcran(1);
	//EffacerEcran(CouleurParNom("White"));	
	EcrireTexte(5, k ,buffsrc,1);
	//ChoisirEcran(2);
	//EffacerEcran(CouleurParNom("White"));
	EcrireTexte(5, 400+k ,buffdest,1);	
	k= k + 3;
	}
   	
   	fclose(destination);
    	fclose(source);
	}

	//ChoisirEcran(0);
	//CopierZone(1,0,4,3,200,200,4,3);
	//CopierZone(2,0,250,3,200,200,250,3);
     }
	}
	
	Touche();
        FermerGraphique();
        
	return 1;
	
}

void argument(char *arg, long long *mem, long long *val) {
	int sign = 0;
	if (arg != NULL) {
		switch(arg[0]) {
			case '#' :  /* si '#' est à l'indice 0*/
				*mem = 0L;	

				arg = arg+1;
				break;
			case '@' : /* si '@' est à l'indice 0*/
				*mem = 2L;
				arg = arg+1;
				break;
			default :
				*mem = 1;
		}
		
		if (arg[0] == '-') {  
			sign = 1;
			arg = arg+1;
		}
		
		*val = strtoll(arg, NULL, 0); 

		if (sign == 1) { *val = 8000-(*val); }
	}
}



/////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////    fonction a creer   //////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////





void nicolas(char* fic_src, char* fic_dest)
{

	//char tab[20];	
	FILE *source = fopen(fic_src,"r");
	FILE *destination = fopen(fic_dest,"w");

	if(source==NULL){
        printf("erreur d'ouverture du fichier %s", fic_src);
        exit(1);
	}
	
	if(destination==NULL){
        printf("erreur d'ouverture du fichier %s", fic_dest);
        exit(1);
	}
	
    
	//do 
	//{
	while(!feof(source)){
	fgets( buff,20,source);
	//fgets (buff2,11,source);
	//for( int j =0;j<2;j++){  
    	printf("%s",buff);
    	//printf("%s %ld\n",buff2,strlen(buff2));
	//printf("%s%ld",buff2,strlen(buff2));
	mnemo = strtok(buff, delim); 
	arg1 = strtok(NULL, delim); 
	arg2 = strtok(NULL, delim);   

	if (strcmp(mnemo,"DAT") == 0) { 
		arg2 = arg1; 
		arg1 = NULL;  
	}
	if (strcmp(mnemo,"JMP") == 0) {  
		arg2 = NULL;  
	}
	if (strcmp(mnemo,"MOV") == 0) { i = 1; }

	if (strcmp(mnemo,"ADD") == 0) { i = 2; }
	
	if (strcmp(mnemo,"SUB") == 0) { i = 3; }
	
	if (strcmp(mnemo,"JMP") == 0) { i = 4; }
	
	if (strcmp(mnemo,"JMZ") == 0) { i = 5; }
	
	if (strcmp(mnemo,"JMG") == 0) { i = 6; }
	
	if (strcmp(mnemo,"DJZ") == 0) { i = 7; }
	
	if (strcmp(mnemo,"CMP") == 0) { i = 8; }
	
	if (strcmp(mnemo,"DAT") == 0) { i = 0; }
	
   	argument(arg1, &mema, &vala); 
	argument(arg2, &memb, &valb); 
		
	i = i << 60;
	mema = mema << 58; 
	if (i == 0)                  
		memb = 0;
	memb = memb << 56; 
	vala = vala << 28;
	valb = valb; 
	le_code = i | le_code;
	le_code = le_code | mema; 
	le_code = le_code | memb; 
	le_code = le_code | vala; 
	le_code = le_code | valb; 

	//destination = fopen(fic_dest,"a");
	
	//for( int j=0;j<20;
	sprintf(buff,"%lld",le_code);
	printf("%s\n",buff);
	fputs(buff,destination);


	//destination = fopen(fic_dest,"a");
	//fprintf(destination,"%s\n",buff2);	

        }
        fclose(destination);
    	fclose(source);


   	//printf ("%016llx\n", le_code); /* print 0000000000001f3f */
	//printf("%lld\n", le_code); /* print 7999 */
	



  
}



/*void nicolas2(char* fic_src, char* fic_dest)
{
	long long int le_code = 0;
   	long long i = 0;
	long long mema = 0;
	long long memb = 0;
	long long vala = 0;
	long long valb = 0;
    	char *mnemo;
	char *arg1;
	char *arg2;
	char buff[12];
	//char tab[20];	
	FILE *source = fopen(fic_src,"r");
	FILE *destination= fopen(fic_dest,"w");

	if(source==NULL){
        printf("erreur d'ouverture du fichier %s", fic_src);
        exit(1);
	}
	

	else if(destination==NULL){
        printf("erreur d'ouverture du fichier %s", fic_dest);
        exit(1);
	}
    

	while(fscanf( source,"%016llx", source )!=NULL){    
    	printf("%s",buff);
	mnemo = strtok(buff, delim); 
	arg1 = strtok(NULL, delim); 
	arg2 = strtok(NULL, delim);   

	if (strcmp(mnemo,"DAT") == 0) { 
		arg2 = arg1; 
		arg1 = NULL;  
	}
	if (strcmp(mnemo,"JMP") == 0) {  
		arg2 = NULL;  
	}
	if (strcmp(mnemo,"MOV") == 0) { i = 1; }

	if (strcmp(mnemo,"ADD") == 0) { i = 2; }
	
	if (strcmp(mnemo,"SUB") == 0) { i = 3; }
	
	if (strcmp(mnemo,"JMP") == 0) { i = 4; }
	
	if (strcmp(mnemo,"JMZ") == 0) { i = 5; }
	
	if (strcmp(mnemo,"JMG") == 0) { i = 6; }
	
	if (strcmp(mnemo,"DJZ") == 0) { i = 7; }
	
	if (strcmp(mnemo,"CMP") == 0) { i = 8; }
	
	if (strcmp(mnemo,"DAT") == 0) { i = 0; }
	
   	argument(arg1, &mema, &vala); 
	argument(arg2, &memb, &valb); 
		
	i = i << 60;
	mema = mema << 58; 
	if (i == 0)                  
		memb = 0;
	memb = memb << 56; 
	vala = vala << 28;
	valb = valb; 
	le_code = i | le_code;
	le_code = le_code | mema; 
	le_code = le_code | memb; 
	le_code = le_code | vala; 
	le_code = le_code | valb; 


	fprintf(destination,"%lld\n",le_code);
	
        }
        
    	fclose(source);
    	fclose(destination);

    
	






		
	printf ("%016llx\n", le_code); 
	printf("%lld\n", le_code); /* print 7999 
	



  
}*/


