# SAE12_2021

Les noms du binome : Petronis Nicolas et DeSousa Hugo


Etat du projet : 

Problème avec le makefile: pour executer le projet, il faut compiler le fichier "PourCompiler.c" 

Fonction nicolas : L'écriture dans le fichier ne marche pas comme il faut, c'est correcte pour la 1er ligne
mais pas pour les suivantes.

Fonction nicolas2(pour la reciproque) : n'est pas complété ;
Le principe est de faire les instructions suivantes : 

chaine esctraité

mnemo = chaine & 0XF00000000000000 

mnemo >> 60

arg1 = chaine & (000011110000000...);

val a = chaine & (0000000011...1...);

val b = chaine & (000000.....011..1);


main : Le texte affiché dans la fenetre graphique est écris en tout petit 


 Ce qui a été fait : 
 - une fonction qui convertis les instructions d'un fichiers en nombre décimaux dans un autre fichier.
 - afficher les instructions et la convertion dans une fenetre graphique. 


 Ce qu'il reste à faire : 
une fonction qui fais l'inverse de la premiere fonction(la reciproque) et une
fonction qui fait combattre les deux virus


Les difficultés rencontré :

- Beaucoup de difficultés pour corriger la fonction nicolas.
- Manque de temps




