#ifndef ARGUMENT_H
#define ARGUMENT_H

void argument(char *arg, long long *mem, long long *val);

/* Convertis une instruction en nombre decimal,
verifie si l'instruction à un comme argument '#', si oui on regarde si il y a un deuxieme argument '@'
et regarde l'argument suivant, si il n'y a rien on on reste au tout début. 
Ensuite il vérifie si l'argument est negatif '-' */

#endif /*ARGUMENT_H */
