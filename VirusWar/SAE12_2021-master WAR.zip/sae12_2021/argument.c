#include<stdio.h> 
#include<stdlib.h>
#include<string.h>
#include<graph.h>

#include "nicolas.h"
#include "argument.h"

void argument(char *arg, long long *mem, long long *val) {
	int sign = 0;
	if (arg != NULL) {
		switch(arg[0]) {
			case '#' :  /* si '#' est à l'indice 0*/
				*mem = 0L;	
				arg = arg+1;
				break;
			case '@' : /* si '@' est à l'indice 0*/
				*mem = 2L;
				arg = arg+1;
				break;
			default :
				*mem = 1;
		}
		
		if (arg[0] == '-') {  
			sign = 1;
			arg = arg+1;
		}
		
		*val = strtoll(arg, NULL, 0); 

		if (sign == 1) { *val = 8000-(*val); }
	}
}