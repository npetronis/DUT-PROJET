#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include<graph.h>
 

 /*fonction pour lire ligne par ligne dans un fichier source, convertir les lignes et les écrires dans
le fichier destination */


	char buff[20];
	char buffsrc[20];
	char buffdest[20];		
	char buff2[20];

int main(int argc, char *argv[]) {
	int k= 10;
	int kk;
	InitialiserGraphique();
	CreerFenetre(0,0,900,900);
	DessinerRectangle(0,0,900,400);
	DessinerRectangle(0,401,900,400);
	DessinerSegment(700,1,700,399);
	DessinerSegment(700,401,700,899);
	EcrireTexte(705, 203,"premier programme",0);
	EcrireTexte(705, 604,"deuxieme programme",0);


        while (1){
    //Si on clique sur le premiere rectangle à droite, afficher le fichier dans la fenetre	
        if(SourisCliquee()){
        if ( _X>=700 && _X<=900 && _Y>=1 && _Y<=399)
        {
        nicolas("redcode.ass","redcode.mars");

    //ouverture des flux de fichiers
   	FILE *source = fopen("redcode2.ass","r");
	FILE *destination = fopen("redcode2.mars","w");
	while(!feof(source) && !feof(destination)){
	fgets( buffsrc,20,source);
	printf("%s",buffsrc);
	fgets( buffdest,20,destination);
	EcrireTexte(5, 800 ,"testes",0);
	//ChoisirEcran(1);
	//EffacerEcran(CouleurParNom("White"));	
	EcrireTexte(5, k ,buffsrc,1);
	//ChoisirEcran(2);
	//EffacerEcran(CouleurParNom("White"));
	EcrireTexte(5, 400+k ,buffdest,1);	
	k= k + 3;
	}
   	
   	fclose(destination);
    fclose(source);
	}

	//ChoisirEcran(0);
	//CopierZone(1,0,4,3,200,200,4,3);
	//CopierZone(2,0,250,3,200,200,250,3);
     }
	}
	
	Touche();
    FermerGraphique();
        
	return 1;
	
}








