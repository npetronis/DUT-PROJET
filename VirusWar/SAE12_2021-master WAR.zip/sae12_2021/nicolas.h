#ifndef NICOLAS_H
#define NICOLAS_H

void nicolas(char* fic_src, char* fic_dest);
/*Prend comme premier argument le fichier source et comme deuxieme argument le fichier
de destination. Les instructions du fichier source sont convertis et écris dans le fichier destination*/


#endif /*NICOLAS_H */
