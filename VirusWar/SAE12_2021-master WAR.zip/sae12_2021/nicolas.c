#include<stdio.h> 
#include<stdlib.h>
#include<string.h>
#include<graph.h>

#include "nicolas.h"
#include "argument.h"

void nicolas(char* fic_src, char* fic_dest)
{
    char delim[] = " "; 
    char *mnemo;
	char *arg1;
	char *arg2;
	long long int le_code = 0;
	long long i = 0;
	long long mema = 0;
	long long memb = 0;
	long long vala = 0;
	long long valb = 0;
	char buff[20];
	//char tab[20];	
	FILE *source = fopen(fic_src,"r");
	FILE *destination = fopen(fic_dest,"w");

	if(source==NULL){
        printf("erreur d'ouverture du fichier %s", fic_src);
        exit(1);
	}
	
	if(destination==NULL){
        printf("erreur d'ouverture du fichier %s", fic_dest);
        exit(1);
	}
	
    
	//do 
	//{
	while(!feof(source)){
	fgets( buff,20,source);
	//fgets (buff2,11,source);
	//for( int j =0;j<2;j++){  
    	printf("%s",buff);
    	//printf("%s %ld\n",buff2,strlen(buff2));
	//printf("%s%ld",buff2,strlen(buff2));
	mnemo = strtok(buff, delim); 
	arg1 = strtok(NULL, delim); 
	arg2 = strtok(NULL, delim);   

	if (strcmp(mnemo,"DAT") == 0) { 
		arg2 = arg1; 
		arg1 = NULL;  
	}
	if (strcmp(mnemo,"JMP") == 0) {  
		arg2 = NULL;  
	}
	if (strcmp(mnemo,"MOV") == 0) { i = 1; }

	if (strcmp(mnemo,"ADD") == 0) { i = 2; }
	
	if (strcmp(mnemo,"SUB") == 0) { i = 3; }
	
	if (strcmp(mnemo,"JMP") == 0) { i = 4; }
	
	if (strcmp(mnemo,"JMZ") == 0) { i = 5; }
	
	if (strcmp(mnemo,"JMG") == 0) { i = 6; }
	
	if (strcmp(mnemo,"DJZ") == 0) { i = 7; }
	
	if (strcmp(mnemo,"CMP") == 0) { i = 8; }
	
	if (strcmp(mnemo,"DAT") == 0) { i = 0; }
	
   	argument(arg1, &mema, &vala); 
	argument(arg2, &memb, &valb); 
		
	i = i << 60;
	mema = mema << 58; 
	if (i == 0)                  
		memb = 0;
	memb = memb << 56; 
	vala = vala << 28;
	valb = valb; 
	le_code = i | le_code;
	le_code = le_code | mema; 
	le_code = le_code | memb; 
	le_code = le_code | vala; 
	le_code = le_code | valb; 

	//destination = fopen(fic_dest,"a");
	
	//for( int j=0;j<20;
	sprintf(buff,"%lld",le_code);
	printf("%s\n",buff);
	fputs(buff,destination);


	//destination = fopen(fic_dest,"a");
	//fprintf(destination,"%s\n",buff2);	

        }
        fclose(destination);
    	fclose(source);


   	//printf ("%016llx\n", le_code); /* print 0000000000001f3f */
	//printf("%lld\n", le_code); /* print 7999 */
	



  
}
